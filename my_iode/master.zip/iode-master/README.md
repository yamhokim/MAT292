# Iode
Iode is an educational software package for ordinary and partial differential equations, and Fourier series.

To download and install a copy of Iode, run this command in Matlab:
```matlab
eval(urlread('https://raw.githubusercontent.com/rslaugesen/iode/master/install.m'))
```

(This command may or may not work with Octave. While Iode does include text-based menus for Octave, we are not maintaining them anymore.)
